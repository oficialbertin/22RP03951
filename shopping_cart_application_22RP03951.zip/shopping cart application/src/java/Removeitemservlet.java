

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author user
 */
public class Removeitemservlet extends HttpServlet {

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String itemToRemove = request.getParameter("name");
        boolean itemRemoved = false;

        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("cart")) {
                    String[] items = cookie.getValue().split(",");
                    StringBuilder newCart = new StringBuilder();
                    for (String item : items) {
                        if (!item.startsWith(itemToRemove + ":")) {
                            if (newCart.length() > 0) newCart.append(",");
                            newCart.append(item);
                        } else {
                            itemRemoved = true;
                        }
                    }
                    Cookie newCartCookie = new Cookie("cart", newCart.toString());
                    newCartCookie.setMaxAge(24 * 60 * 60); // 1 day
                    response.addCookie(newCartCookie);
                    
                    out.println("<html><body>");
                    if (itemRemoved) {
                        out.println("<h2>Item Removed from Cart</h2>");
                        out.println("<p>Removed: " + itemToRemove + "</p>");
                    } else {
                        out.println("<h2>Item Not Found in Cart</h2>");
                        out.println("<p>Could not find: " + itemToRemove + "</p>");
                    }
                    out.println("<p>Updated cart: " + newCart.toString() + "</p>");
                    out.println("<a href='index.html'> <button type=\"button\">Back to main page</button></a>");
                    out.println("</body></html>");
                    return;
                }
            }
        }

        out.println("<html><body>");
        out.println("<h2>Cart Not Found</h2>");
        out.println("<p>No cart cookie found.</p>");
        out.println("<a href='index.html'>Back to main page</a>");
        out.println("</body></html>");
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
